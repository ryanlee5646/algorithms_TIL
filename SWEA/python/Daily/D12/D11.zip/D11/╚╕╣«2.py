import sys
sys.stdin = open("회문2.txt", "r")

for t in range(1,11):
    tc = int(input())